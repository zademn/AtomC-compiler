use std::mem::{size_of, size_of_val};
const STACK_SIZE: usize = 32 * 1024;

enum Opcodes {
    OAddC,
    OAddD,
    OAddI,
    OAndA,
    OAndC,
    OAndD,
    OAndI,
    OCall,
    OCallext,
    OCastCD,
    OCastCI,
    OCastDC,
    OCastDI,
    OCastIC,
    OCastID,
    ODivC,
    ODivD,
    ODivI,
    ODrop,
    OEnter,
    OEqA,
    OEqC,
    OEqD,
    OEqI,
    OGreaterC,
    OGreaterD,
    OGreaterI,
    OGreaterEqC,
    OGreaterEqD,
    OGreaterEqI,
    OHalt,
    OInsert,
    OJfA,
    OJfC,
    OJfD,
    OJfI,
    OJmp,
    OJtA,
    OJtC,
    OJtD,
    OJtI,
    OLessC,
    OLessD,
    OLessI,
    OLeesEqC,
    OLessEqD,
    OLessEqI,
    OLoad,
    OMulC,
    OMulD,
    OMulI,
    ONegC,
    ONegD,
    ONegI,
    ONop,
    ONotA,
    ONotC,
    ONotD,
    ONotI,
    ONotEqA,
    ONotEqC,
    ONotEqD,
    ONotEqI,
    OOffset,
    OOrA,
    OOrC,
    OOrD,
    OOrI,
    OPushFPAddr,
    OPushCtA,
    OPushCtC,
    OPushCtD,
    OPushCtI,
    ORet,
    OStore,
    OSubC,
    OSubD,
    OSubI,
}
// struct Instr{
//     opcode:
// }
struct VirtualMachine<T> {
    sp: *const T,          // stack pointer
    stack_after: *const T, // used for stack limit
    stack: [u8; STACK_SIZE],
}
impl<T: Sized> VirtualMachine<T> {
    fn pushd(&mut self, d: f32) {
        if unsafe { self.sp.add(size_of::<f32>()) > self.stack_after } {
            panic!("Out of stack");
        }
        self.sp = (&d as *const f32).cast::<T>();
        self.sp = unsafe { self.sp.add(size_of::<f32>()) };
    }
}
